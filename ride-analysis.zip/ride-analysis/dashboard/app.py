"""
Interactive dashboard for the ride-hailing dataset.
Run: streamlit run dashboard/app.py
"""

import pandas as pd
import streamlit as st
import plotly.express as px

st.set_page_config(page_title="Ride-Hailing Analytics", layout="wide")

@st.cache_data
def load_data():
    df = pd.read_csv("data/rides_clean.csv")
    df["ride_date"] = pd.to_datetime(df["ride_date"])
    return df

df = load_data()

st.title("🚗 Ride-Hailing Analytics Dashboard")
st.caption("Synthetic dataset — Uber/Ola-style ride operations analysis")

# ---------------- Sidebar filters ----------------
st.sidebar.header("Filters")
cities = st.sidebar.multiselect("City", sorted(df["city"].unique()), default=list(df["city"].unique()))
vehicle_types = st.sidebar.multiselect("Vehicle Type", sorted(df["vehicle_type"].unique()), default=list(df["vehicle_type"].unique()))
date_range = st.sidebar.date_input(
    "Date range",
    [df["ride_date"].min(), df["ride_date"].max()],
)

mask = (
    df["city"].isin(cities)
    & df["vehicle_type"].isin(vehicle_types)
    & (df["ride_date"] >= pd.to_datetime(date_range[0]))
    & (df["ride_date"] <= pd.to_datetime(date_range[1]))
)
fdf = df[mask]

# ---------------- KPI row ----------------
col1, col2, col3, col4 = st.columns(4)
total_rides = len(fdf)
completed = fdf["is_completed"].sum()
completion_rate = (completed / total_rides * 100) if total_rides else 0
total_revenue = fdf["fare"].sum()
avg_fare = fdf.loc[fdf["is_completed"], "fare"].mean() if completed else 0

col1.metric("Total Rides", f"{total_rides:,}")
col2.metric("Completion Rate", f"{completion_rate:.1f}%")
col3.metric("Total Revenue", f"₹{total_revenue:,.0f}")
col4.metric("Avg Fare (Completed)", f"₹{avg_fare:,.0f}")

st.divider()

# ---------------- Charts ----------------
c1, c2 = st.columns(2)

with c1:
    st.subheader("Revenue by City")
    rev_city = fdf.groupby("city")["fare"].sum().sort_values(ascending=False).reset_index()
    fig = px.bar(rev_city, x="city", y="fare", labels={"fare": "Revenue"})
    st.plotly_chart(fig, use_container_width=True)

with c2:
    st.subheader("Ride Status Breakdown")
    status_counts = fdf["ride_status"].value_counts().reset_index()
    status_counts.columns = ["ride_status", "count"]
    fig = px.pie(status_counts, names="ride_status", values="count", hole=0.4)
    st.plotly_chart(fig, use_container_width=True)

c3, c4 = st.columns(2)

with c3:
    st.subheader("Demand by Hour of Day")
    hourly = fdf.groupby("ride_hour").size().reset_index(name="rides")
    fig = px.line(hourly, x="ride_hour", y="rides", markers=True)
    st.plotly_chart(fig, use_container_width=True)

with c4:
    st.subheader("Vehicle Type Performance")
    veh = fdf.groupby("vehicle_type").agg(
        rides=("ride_id", "count"),
        avg_fare=("fare", "mean"),
    ).reset_index()
    fig = px.bar(veh, x="vehicle_type", y="rides", color="avg_fare",
                 labels={"avg_fare": "Avg Fare"})
    st.plotly_chart(fig, use_container_width=True)

st.subheader("Monthly Revenue Trend")
monthly = fdf.groupby("ride_month")["fare"].sum().reset_index()
fig = px.line(monthly, x="ride_month", y="fare", markers=True)
st.plotly_chart(fig, use_container_width=True)

st.subheader("Cancellation Reasons")
cancel_df = fdf[fdf["cancel_reason"] != "N/A"]
if not cancel_df.empty:
    reasons = cancel_df["cancel_reason"].value_counts().reset_index()
    reasons.columns = ["reason", "count"]
    fig = px.bar(reasons, x="reason", y="count")
    st.plotly_chart(fig, use_container_width=True)
else:
    st.info("No cancellations in the selected filter range.")

st.divider()
st.caption("Data is synthetic and generated for portfolio/demo purposes.")
