-- =========================================================
-- Ride-Hailing Analysis — SQL Queries
-- Run against data/rides.db (built by load_to_sql.py)
-- Table: rides
-- =========================================================

-- 1. Overall KPIs
SELECT
    COUNT(*) AS total_rides,
    SUM(is_completed) AS completed_rides,
    ROUND(100.0 * SUM(is_completed) / COUNT(*), 2) AS completion_rate_pct,
    ROUND(SUM(fare), 2) AS total_revenue,
    ROUND(AVG(fare), 2) AS avg_fare_per_completed_ride
FROM rides;

-- 2. Revenue and ride volume by city
SELECT
    city,
    COUNT(*) AS total_rides,
    SUM(is_completed) AS completed_rides,
    ROUND(SUM(fare), 2) AS total_revenue,
    ROUND(AVG(fare), 2) AS avg_fare
FROM rides
GROUP BY city
ORDER BY total_revenue DESC;

-- 3. Cancellation rate and top cancellation reasons
SELECT
    ride_status,
    COUNT(*) AS num_rides,
    ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM rides), 2) AS pct_of_total
FROM rides
GROUP BY ride_status
ORDER BY num_rides DESC;

SELECT
    cancel_reason,
    COUNT(*) AS num_rides
FROM rides
WHERE cancel_reason != 'N/A'
GROUP BY cancel_reason
ORDER BY num_rides DESC;

-- 4. Demand by hour of day (find peak hours)
SELECT
    ride_hour,
    COUNT(*) AS num_rides,
    ROUND(AVG(surge_multiplier), 2) AS avg_surge
FROM rides
GROUP BY ride_hour
ORDER BY ride_hour;

-- 5. Demand by day of week
SELECT
    day_of_week,
    COUNT(*) AS num_rides,
    ROUND(SUM(fare), 2) AS total_revenue
FROM rides
GROUP BY day_of_week
ORDER BY num_rides DESC;

-- 6. Vehicle type performance
SELECT
    vehicle_type,
    COUNT(*) AS total_rides,
    ROUND(AVG(fare), 2) AS avg_fare,
    ROUND(AVG(distance_km), 2) AS avg_distance_km,
    ROUND(AVG(driver_rating), 2) AS avg_driver_rating
FROM rides
GROUP BY vehicle_type
ORDER BY total_rides DESC;

-- 7. Monthly revenue trend
SELECT
    ride_month,
    COUNT(*) AS total_rides,
    ROUND(SUM(fare), 2) AS total_revenue
FROM rides
GROUP BY ride_month
ORDER BY ride_month;

-- 8. Top 10 drivers by completed rides and revenue generated
SELECT
    driver_id,
    COUNT(*) AS completed_rides,
    ROUND(SUM(fare), 2) AS revenue_generated,
    ROUND(AVG(rider_rating), 2) AS avg_rider_rating_given
FROM rides
WHERE is_completed = 1
GROUP BY driver_id
ORDER BY revenue_generated DESC
LIMIT 10;

-- 9. Payment method distribution
SELECT
    payment_method,
    COUNT(*) AS num_rides,
    ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM rides WHERE is_completed = 1), 2) AS pct_of_completed
FROM rides
WHERE is_completed = 1
GROUP BY payment_method
ORDER BY num_rides DESC;

-- 10. Surge pricing impact on cancellations
SELECT
    CASE
        WHEN surge_multiplier = 1.0 THEN 'No Surge'
        WHEN surge_multiplier <= 1.5 THEN 'Moderate Surge'
        ELSE 'High Surge'
    END AS surge_bucket,
    COUNT(*) AS total_rides,
    SUM(CASE WHEN ride_status != 'Completed' THEN 1 ELSE 0 END) AS cancelled_rides,
    ROUND(100.0 * SUM(CASE WHEN ride_status != 'Completed' THEN 1 ELSE 0 END) / COUNT(*), 2) AS cancel_rate_pct
FROM rides
GROUP BY surge_bucket;
