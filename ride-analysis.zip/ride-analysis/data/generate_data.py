"""
Generates a synthetic ride-hailing (Uber/Ola-style) dataset.
Run first: python data/generate_data.py
Creates: data/rides_raw.csv, data/drivers.csv
"""

import random
import pandas as pd
from datetime import datetime, timedelta

random.seed(42)

CITIES = ["Bhubaneswar", "Delhi", "Mumbai", "Bangalore", "Pune", "Hyderabad", "Chennai"]
VEHICLE_TYPES = ["Mini", "Sedan", "SUV", "Auto", "Bike"]
PAYMENT_METHODS = ["UPI", "Card", "Cash", "Wallet"]
RIDE_STATUS = ["Completed", "Completed", "Completed", "Completed", "Cancelled by Rider", "Cancelled by Driver", "No Show"]
CANCEL_REASONS = {
    "Cancelled by Rider": ["Changed plans", "Found alternate ride", "Price too high", "Wait too long"],
    "Cancelled by Driver": ["Rider not reachable", "Traffic/route issue", "Vehicle issue"],
    "No Show": ["Rider did not show up"],
}

N_DRIVERS = 200
N_RIDERS = 3000
N_RIDES = 8000

# ---- Drivers ----
drivers = []
for i in range(1, N_DRIVERS + 1):
    drivers.append({
        "driver_id": f"DRV{i:04d}",
        "city": random.choice(CITIES),
        "vehicle_type": random.choice(VEHICLE_TYPES),
        "join_year": random.randint(2019, 2025),
        "driver_rating": round(random.uniform(3.5, 5.0), 2),
    })
drivers_df = pd.DataFrame(drivers)

# ---- Rides ----
start_date = datetime(2025, 1, 1)
rows = []
for i in range(1, N_RIDES + 1):
    driver = random.choice(drivers)
    status = random.choice(RIDE_STATUS)
    ride_date = start_date + timedelta(
        days=random.randint(0, 364),
        hours=random.randint(0, 23),
        minutes=random.randint(0, 59),
    )
    distance_km = round(random.uniform(1, 35), 2)
    base_fare = round(distance_km * random.uniform(9, 14), 2)
    surge_multiplier = random.choice([1.0, 1.0, 1.0, 1.2, 1.5, 2.0])  # mostly no surge
    fare = round(base_fare * surge_multiplier, 2) if status == "Completed" else 0.0
    wait_time_min = random.randint(1, 15)
    trip_time_min = round(distance_km * random.uniform(2, 4), 1) if status == "Completed" else None
    rider_rating = round(random.uniform(2.0, 5.0), 1) if status == "Completed" else None

    cancel_reason = None
    if status != "Completed" and status in CANCEL_REASONS:
        cancel_reason = random.choice(CANCEL_REASONS[status])

    # inject messiness on purpose
    payment_method = random.choice(PAYMENT_METHODS) if status == "Completed" else None
    vehicle_type_raw = random.choice([driver["vehicle_type"], driver["vehicle_type"].lower(), driver["vehicle_type"].upper()])

    rows.append({
        "ride_id": f"RIDE{i:06d}",
        "rider_id": f"RID{random.randint(1, N_RIDERS):05d}",
        "driver_id": driver["driver_id"],
        "city": driver["city"],
        "vehicle_type": vehicle_type_raw,
        "ride_datetime": ride_date.strftime("%Y-%m-%d %H:%M:%S"),
        "distance_km": distance_km,
        "surge_multiplier": surge_multiplier,
        "fare": fare,
        "payment_method": payment_method,
        "wait_time_min": wait_time_min,
        "trip_time_min": trip_time_min,
        "ride_status": status,
        "cancel_reason": cancel_reason,
        "rider_rating": rider_rating,
        "driver_rating": driver["driver_rating"],
    })

df = pd.DataFrame(rows)

# duplicate a few rows on purpose (to practice de-duping)
dupes = df.sample(40, random_state=1)
df = pd.concat([df, dupes], ignore_index=True)

# introduce a few missing distance values on purpose
missing_idx = df.sample(frac=0.02, random_state=2).index
df.loc[missing_idx, "distance_km"] = None

df.to_csv("data/rides_raw.csv", index=False)
drivers_df.to_csv("data/drivers.csv", index=False)

print(f"Generated {len(df)} ride rows -> data/rides_raw.csv")
print(f"Generated {len(drivers_df)} drivers -> data/drivers.csv")
