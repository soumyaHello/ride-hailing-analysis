"""
Loads the cleaned CSV into a SQLite database so the SQL queries can be run.
Run after clean_data.py: python data/load_to_sql.py
Creates: data/rides.db
"""

import sqlite3
import pandas as pd

df = pd.read_csv("data/rides_clean.csv")

conn = sqlite3.connect("data/rides.db")
df.to_sql("rides", conn, if_exists="replace", index=False)

# quick sanity check
cur = conn.cursor()
cur.execute("SELECT COUNT(*) FROM rides")
print(f"Loaded {cur.fetchone()[0]} rows into data/rides.db (table: rides)")

conn.close()
