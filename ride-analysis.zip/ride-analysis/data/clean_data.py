"""
Cleans the raw ride-hailing dataset and produces an analysis-ready file.
Run after generate_data.py: python data/clean_data.py
Reads:  data/rides_raw.csv
Writes: data/rides_clean.csv
"""

import pandas as pd

df = pd.read_csv("data/rides_raw.csv")
print(f"Raw rows: {len(df)}")

# 1. Drop exact duplicate rows
df = df.drop_duplicates(subset="ride_id", keep="first")
print(f"After removing duplicates: {len(df)}")

# 2. Standardize vehicle_type casing (e.g. "mini", "MINI", "Mini" -> "Mini")
df["vehicle_type"] = df["vehicle_type"].str.strip().str.title()

# 3. Parse datetime and derive useful columns
df["ride_datetime"] = pd.to_datetime(df["ride_datetime"])
df["ride_date"] = df["ride_datetime"].dt.date
df["ride_hour"] = df["ride_datetime"].dt.hour
df["ride_month"] = df["ride_datetime"].dt.to_period("M").astype(str)
df["day_of_week"] = df["ride_datetime"].dt.day_name()

# 4. Handle missing distance_km -> fill with median distance per vehicle_type
df["distance_km"] = df.groupby("vehicle_type")["distance_km"].transform(
    lambda x: x.fillna(x.median())
)

# 5. Flag cancelled/no-show rides clearly
df["is_completed"] = df["ride_status"].eq("Completed")

# 6. Fill missing payment_method / cancel_reason with "N/A" (they're legitimately empty
#    for cancelled rides / completed rides respectively, not "dirty" data)
df["payment_method"] = df["payment_method"].fillna("N/A")
df["cancel_reason"] = df["cancel_reason"].fillna("N/A")

# 7. Sanity checks
assert df["fare"].min() >= 0, "Negative fares found!"
assert df["ride_id"].is_unique, "Duplicate ride_id still present!"

# 8. Reorder / select final columns
final_cols = [
    "ride_id", "rider_id", "driver_id", "city", "vehicle_type",
    "ride_date", "ride_hour", "ride_month", "day_of_week",
    "distance_km", "surge_multiplier", "fare", "payment_method",
    "wait_time_min", "trip_time_min", "ride_status", "is_completed",
    "cancel_reason", "rider_rating", "driver_rating",
]
df = df[final_cols]

df.to_csv("data/rides_clean.csv", index=False)
print(f"Clean rows: {len(df)} -> data/rides_clean.csv")
print("\nMissing values per column:")
print(df.isna().sum())
