# 🚗 Ride-Hailing Data Analysis (Uber/Ola-style)

A data analyst portfolio project analyzing ride-hailing operations: ride volume, revenue,
cancellations, demand patterns, and driver/vehicle performance. Built with Python, SQL, and
an interactive Streamlit dashboard.

> **Note on data:** This project uses a **synthetic dataset** (generated with `data/generate_data.py`)
> that mimics real ride-hailing data — including intentional messiness (duplicates, missing values,
> inconsistent casing) to practice realistic data cleaning.

---

## 📌 Problem Statement

As a data analyst supporting a ride-hailing operations team, analyze ride data to answer:
- What's our ride completion rate, and where are we losing rides to cancellations?
- Which cities and vehicle types drive the most revenue?
- When is rider demand highest, and does surge pricing correlate with cancellations?
- Which drivers/vehicle segments are underperforming?

---

## 🛠️ Tools Used

- **Python** (pandas) — data generation & cleaning
- **SQLite + SQL** — aggregation queries
- **Jupyter Notebook** (matplotlib, seaborn) — exploratory analysis
- **Streamlit + Plotly** — interactive dashboard

---

## 📂 Project Structure

```
ride-analysis/
├── data/
│   ├── generate_data.py     # creates synthetic raw dataset
│   ├── clean_data.py        # cleans raw data -> rides_clean.csv
│   ├── load_to_sql.py       # loads clean data into SQLite (rides.db)
│   ├── rides_raw.csv        # generated (not committed if large)
│   ├── rides_clean.csv      # generated
│   └── drivers.csv          # generated
├── sql/
│   └── analysis_queries.sql # 10 business-question SQL queries
├── notebooks/
│   └── analysis.ipynb       # EDA with charts + written insights
├── dashboard/
│   └── app.py                # Streamlit dashboard
├── requirements.txt
└── README.md
```

---

## ▶️ How to Run

### 1. Setup
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Generate & clean data
```bash
cd data
python generate_data.py     # creates rides_raw.csv, drivers.csv
python clean_data.py        # creates rides_clean.csv
python load_to_sql.py       # creates rides.db
cd ..
```

### 3. Run SQL queries
Open `sql/analysis_queries.sql` in any SQLite client, or run via Python:
```bash
python -c "
import sqlite3, pandas as pd
conn = sqlite3.connect('data/rides.db')
print(pd.read_sql('SELECT city, SUM(fare) AS revenue FROM rides GROUP BY city ORDER BY revenue DESC', conn))
"
```

### 4. Explore in Jupyter
```bash
jupyter notebook notebooks/analysis.ipynb
```

### 5. Launch the dashboard
```bash
streamlit run dashboard/app.py
```
Opens at `http://localhost:8501` with filters for city, vehicle type, and date range.

---

## 📊 Key Findings *(fill in with your actual numbers after running)*

- Overall completion rate: **__%**
- Top revenue city: **____**
- Peak demand hour: **____**
- Cancellation rate at high surge vs no surge: **__% vs __%**

## 💡 Business Recommendations *(fill in after analysis)*

1. ...
2. ...
3. ...

---

## 🔮 What I'd Add With More Time

- Replace synthetic data with a real public dataset (e.g., NYC TLC trip data)
- Predictive model for cancellation likelihood
- Driver supply-demand heatmap by geography
- A/B testing framework for surge pricing thresholds
- Deploy dashboard (Streamlit Community Cloud) with a public link
